# IO.Swagger.Api.GroupApi

All URIs are relative to *https://localhost:9669*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AddGroup**](GroupApi.md#addgroup) | **POST** /Group | Добавление группы
[**DeleteGroup**](GroupApi.md#deletegroup) | **DELETE** /Group/deleteById/{groupId} | Удаление группы по ID
[**GetGroupById**](GroupApi.md#getgroupbyid) | **GET** /Group/findById/{groupId} | Поиск группы по ID
[**UpdateGroup**](GroupApi.md#updategroup) | **PUT** /Group | Обновление группы пользователей

<a name="addgroup"></a>
# **AddGroup**
> Group AddGroup (Group body)

Добавление группы

Добавление группы в базу данных

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AddGroupExample
    {
        public void main()
        {
            var apiInstance = new GroupApi();
            var body = new Group(); // Group | Добавление группы в базу данных

            try
            {
                // Добавление группы
                Group result = apiInstance.AddGroup(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GroupApi.AddGroup: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Group**](Group.md)| Добавление группы в базу данных | 

### Return type

[**Group**](Group.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml, application/x-www-form-urlencoded
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="deletegroup"></a>
# **DeleteGroup**
> void DeleteGroup (long? groupId, string groupId = null)

Удаление группы по ID

Удаление группы в базе данных

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteGroupExample
    {
        public void main()
        {
            var apiInstance = new GroupApi();
            var groupId = 789;  // long? | ID - идентификатор группы
            var groupId = groupId_example;  // string |  (optional) 

            try
            {
                // Удаление группы по ID
                apiInstance.DeleteGroup(groupId, groupId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GroupApi.DeleteGroup: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupId** | **long?**| ID - идентификатор группы | 
 **groupId** | **string**|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getgroupbyid"></a>
# **GetGroupById**
> Group GetGroupById (long? groupId)

Поиск группы по ID

Поиск группы в базе данных

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetGroupByIdExample
    {
        public void main()
        {
            var apiInstance = new GroupApi();
            var groupId = 789;  // long? | Поиск группы

            try
            {
                // Поиск группы по ID
                Group result = apiInstance.GetGroupById(groupId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GroupApi.GetGroupById: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupId** | **long?**| Поиск группы | 

### Return type

[**Group**](Group.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="updategroup"></a>
# **UpdateGroup**
> Group UpdateGroup (Group body)

Обновление группы пользователей

Обновить группу пользователей

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UpdateGroupExample
    {
        public void main()
        {
            var apiInstance = new GroupApi();
            var body = new Group(); // Group | Обновление группы

            try
            {
                // Обновление группы пользователей
                Group result = apiInstance.UpdateGroup(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GroupApi.UpdateGroup: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Group**](Group.md)| Обновление группы | 

### Return type

[**Group**](Group.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml, application/x-www-form-urlencoded
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
