# IO.Swagger.Model.Robot
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** |  | [optional] 
**Model** | **string** |  | 
**Version** | **string** |  | 
**Charge** | **long?** |  | 
**GarbageContainer** | **long?** |  | 
**RobotPollution** | **long?** |  | 
**NextService** | **long?** |  | 
**SerialNumber** | **string** |  | 
**IpAddress** | **long?** |  | 
**GroupId** | **long?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

