# IO.Swagger.Api.RobotApi

All URIs are relative to *https://localhost:9669*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AddRobot**](RobotApi.md#addrobot) | **POST** /Robot | Добавление робота-пылесоса
[**DeleteRobot**](RobotApi.md#deleterobot) | **DELETE** /Robot/deleteById/{robotId} | Удаление робота-пылесоса по ID
[**GetRobotById**](RobotApi.md#getrobotbyid) | **GET** /Robot/robotById/{robotId} | Поиск робота-пылесоса по ID
[**UpdateRobot**](RobotApi.md#updaterobot) | **PUT** /Robot | Обновление робота-пылесоса

<a name="addrobot"></a>
# **AddRobot**
> Robot AddRobot (Robot body)

Добавление робота-пылесоса

Добавить робот-пылесос в базу данных

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AddRobotExample
    {
        public void main()
        {
            var apiInstance = new RobotApi();
            var body = new Robot(); // Robot | Добавить робот-пылесос в базу данных

            try
            {
                // Добавление робота-пылесоса
                Robot result = apiInstance.AddRobot(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RobotApi.AddRobot: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Robot**](Robot.md)| Добавить робот-пылесос в базу данных | 

### Return type

[**Robot**](Robot.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml, application/x-www-form-urlencoded
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="deleterobot"></a>
# **DeleteRobot**
> void DeleteRobot (long? robotId, string robotId = null)

Удаление робота-пылесоса по ID

Удаление робота-пылесоса из базы данных

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteRobotExample
    {
        public void main()
        {
            var apiInstance = new RobotApi();
            var robotId = 789;  // long? | ID - идентификатор робота-пылесоса
            var robotId = robotId_example;  // string |  (optional) 

            try
            {
                // Удаление робота-пылесоса по ID
                apiInstance.DeleteRobot(robotId, robotId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RobotApi.DeleteRobot: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **robotId** | **long?**| ID - идентификатор робота-пылесоса | 
 **robotId** | **string**|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getrobotbyid"></a>
# **GetRobotById**
> Robot GetRobotById (long? robotId)

Поиск робота-пылесоса по ID

Поиск робота-пылесоса в базе данных

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetRobotByIdExample
    {
        public void main()
        {
            var apiInstance = new RobotApi();
            var robotId = 789;  // long? | roborID - идентификатор робота-пылесоса

            try
            {
                // Поиск робота-пылесоса по ID
                Robot result = apiInstance.GetRobotById(robotId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RobotApi.GetRobotById: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **robotId** | **long?**| roborID - идентификатор робота-пылесоса | 

### Return type

[**Robot**](Robot.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="updaterobot"></a>
# **UpdateRobot**
> Robot UpdateRobot (Robot body)

Обновление робота-пылесоса

Обновление данных о роботе пылесосе в базе данных

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UpdateRobotExample
    {
        public void main()
        {
            var apiInstance = new RobotApi();
            var body = new Robot(); // Robot | Обновление данных о роботе пылесосе в базе данных

            try
            {
                // Обновление робота-пылесоса
                Robot result = apiInstance.UpdateRobot(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RobotApi.UpdateRobot: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Robot**](Robot.md)| Обновление данных о роботе пылесосе в базе данных | 

### Return type

[**Robot**](Robot.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml, application/x-www-form-urlencoded
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
