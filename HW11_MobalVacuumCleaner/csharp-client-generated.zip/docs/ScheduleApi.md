# IO.Swagger.Api.ScheduleApi

All URIs are relative to *https://localhost:9669*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AddSchedule**](ScheduleApi.md#addschedule) | **POST** /Schedule | Добавление расписания
[**DeleteSchedule**](ScheduleApi.md#deleteschedule) | **DELETE** /Schedule/deleteById/{Id} | Удаление расписания по ID
[**GetScheduleById**](ScheduleApi.md#getschedulebyid) | **GET** /Schedule/findById/{Id} | Поиск расписания по ID
[**UpdateSchedule**](ScheduleApi.md#updateschedule) | **PUT** /Schedule | Обновление расписания уборки

<a name="addschedule"></a>
# **AddSchedule**
> Schedule AddSchedule (Schedule body)

Добавление расписания

Добавление расписания в базу данных

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AddScheduleExample
    {
        public void main()
        {
            var apiInstance = new ScheduleApi();
            var body = new Schedule(); // Schedule | Добавление расписания в базу данных

            try
            {
                // Добавление расписания
                Schedule result = apiInstance.AddSchedule(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ScheduleApi.AddSchedule: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Schedule**](Schedule.md)| Добавление расписания в базу данных | 

### Return type

[**Schedule**](Schedule.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml, application/x-www-form-urlencoded
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="deleteschedule"></a>
# **DeleteSchedule**
> void DeleteSchedule (long? id, string id = null)

Удаление расписания по ID

Удаление расписания из базы данных

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteScheduleExample
    {
        public void main()
        {
            var apiInstance = new ScheduleApi();
            var id = 789;  // long? | ID - идентификатор расписания
            var id = id_example;  // string |  (optional) 

            try
            {
                // Удаление расписания по ID
                apiInstance.DeleteSchedule(id, id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ScheduleApi.DeleteSchedule: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **long?**| ID - идентификатор расписания | 
 **id** | **string**|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getschedulebyid"></a>
# **GetScheduleById**
> Schedule GetScheduleById (long? id)

Поиск расписания по ID

Поиск расписания в базе данных

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetScheduleByIdExample
    {
        public void main()
        {
            var apiInstance = new ScheduleApi();
            var id = 789;  // long? | ID - идентификатор пользователя

            try
            {
                // Поиск расписания по ID
                Schedule result = apiInstance.GetScheduleById(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ScheduleApi.GetScheduleById: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **long?**| ID - идентификатор пользователя | 

### Return type

[**Schedule**](Schedule.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="updateschedule"></a>
# **UpdateSchedule**
> Schedule UpdateSchedule (Schedule body)

Обновление расписания уборки

Обновление расписания в базе данных

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UpdateScheduleExample
    {
        public void main()
        {
            var apiInstance = new ScheduleApi();
            var body = new Schedule(); // Schedule | Обновление расписания в базе данных

            try
            {
                // Обновление расписания уборки
                Schedule result = apiInstance.UpdateSchedule(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ScheduleApi.UpdateSchedule: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Schedule**](Schedule.md)| Обновление расписания в базе данных | 

### Return type

[**Schedule**](Schedule.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml, application/x-www-form-urlencoded
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
