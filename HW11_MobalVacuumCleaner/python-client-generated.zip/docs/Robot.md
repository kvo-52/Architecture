# Robot

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**model** | **str** |  | 
**version** | **str** |  | 
**charge** | **int** |  | 
**garbage_container** | **int** |  | 
**robot_pollution** | **int** |  | 
**next_service** | **int** |  | 
**serial_number** | **str** |  | 
**ip_address** | **int** |  | 
**group_id** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

