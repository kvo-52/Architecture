from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from swagger_client.api.group_api import GroupApi
from swagger_client.api.robot_api import RobotApi
from swagger_client.api.schedule_api import ScheduleApi
from swagger_client.api.user_api import UserApi
